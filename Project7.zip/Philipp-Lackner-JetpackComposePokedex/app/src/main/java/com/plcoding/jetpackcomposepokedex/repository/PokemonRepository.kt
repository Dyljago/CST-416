package com.plcoding.jetpackcomposepokedex.repository

import com.plcoding.jetpackcomposepokedex.data.remote.PokeApi
import com.plcoding.jetpackcomposepokedex.data.remote.responses.Pokemon
import com.plcoding.jetpackcomposepokedex.data.remote.responses.PokemonList
import com.plcoding.jetpackcomposepokedex.util.Resource
import dagger.hilt.android.scopes.ActivityScoped
import java.lang.Exception
import javax.inject.Inject

@ActivityScoped // make it the same as activity lifetime
class PokemonRepository @Inject constructor(
    private val api: PokeApi
) {

    suspend fun getPokemonList(limit: Int, offset: Int): Resource<PokemonList> {
        val response = try {
            api.getPokemonList(limit, offset)
        } catch (e: Exception) {
            return Resource.Error("An unknown error occurred.")
        }
        return Resource.Success(data = response)
    }

    suspend fun getPokemonInfo(pokemonName: String): Resource<Pokemon> {
        val response = try {
            api.getPokemonInfo(pokemonName)
        } catch (e: Exception) {
            return Resource.Error("An unknown error occurred.")
        }
        return Resource.Success(data = response)
    }

    // Custom function to get all pokemon names and pair them with their id num for the url
    suspend fun getAllPokemonNames(): MutableList<Pair<String, Int>> {
        try {
            // Get list of all pokemon - goes to 1302 (kind of 1025)
            val response = api.getPokemonList(1500, 0)
            // Pair the name and id of each pokemon
            val result = response.results.map { Pair(it.name, it.url.trimEnd('/').substringAfterLast("/").toInt()) }.toMutableList()
            // Return resulting list
            return result
        } catch (e: Exception) {
            // Error occurred, return nothing
            return mutableListOf()
        }
    }
}