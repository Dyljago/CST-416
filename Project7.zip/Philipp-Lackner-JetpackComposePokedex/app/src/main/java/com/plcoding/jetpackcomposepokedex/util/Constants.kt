package com.plcoding.jetpackcomposepokedex.util

object Constants {
    const val PAGE_SIZE = 20
}