package com.plcoding.jetpackcomposepokedex.pokemonlist

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.palette.graphics.Palette
import com.plcoding.jetpackcomposepokedex.data.models.PokedexListEntry
import com.plcoding.jetpackcomposepokedex.data.remote.responses.Pokemon
import com.plcoding.jetpackcomposepokedex.repository.PokemonRepository
import com.plcoding.jetpackcomposepokedex.util.Constants.PAGE_SIZE
import com.plcoding.jetpackcomposepokedex.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class PokemonListViewModel @Inject constructor(
    private val repository: PokemonRepository
): ViewModel() {

    private var curPage = 0

    var pokemonList = mutableStateOf<List<PokedexListEntry>>(listOf()) // mutableStateListOf<PokedexListEntry>()
    var pokemonNameList = mutableListOf<Pair<String, Int>>()
    var loadError = mutableStateOf("")
    var isLoading = mutableStateOf(false)
    var endReached = mutableStateOf(false)

    private var cachedPokemonList = listOf<PokedexListEntry>()
    private var isSearchStarting = true
    var isSearching = mutableStateOf(false)

    init {
        // Load pokemon page
        loadPokemonPaginated()
        viewModelScope.launch {
            // Load all pokemon on a join so that it does not proceed until after it is done
            loadAllPokemon()?.join()
            // Debug statements
            Log.d("ALL POKEMON", "ALL POKEMON LOADED")
            var i = 0
            for(pokemon in pokemonNameList) {
                i++
                Log.d("ALL POKEMON", i.toString() + ": " + pokemon.toString())
            }
        }
    }

    // Custom job function which loads all pokemon into the system
    private fun loadAllPokemon(): Job? {
        return viewModelScope.launch {
            // Get pokemon list
            pokemonNameList = repository.getAllPokemonNames()
        }
    }

    fun searchPokemonList(query: String) {
        val listToSearch = if (isSearchStarting) {
            pokemonList.value
        } else {
            // at least one char has entered
            cachedPokemonList
        }

        viewModelScope.launch(Dispatchers.Default) {
            if (query.isEmpty()) {
                pokemonList.value = cachedPokemonList
                isSearching.value = false
                isSearchStarting = true
                return@launch
            }
            val result = listToSearch.filter {
                it.pokemonName.contains(query.trim(), ignoreCase = true) || it.number.toString() == query.trim()
            }

            if (isSearchStarting) {
                cachedPokemonList = pokemonList.value
                isSearchStarting = false
            }

            pokemonList.value = result
            isSearching.value = true
        }
    }

    // Custom function to search through the fully loaded list
    fun searchPokemonListUpdated(query: String) {
        // If the list is empty then return
        if (pokemonNameList.isEmpty()) {
            return
        }

        Log.d("PARTIAL SEARCH", "INITIATED")
        viewModelScope.launch(Dispatchers.Default) {
            // If the query is empty then return to the launch of the viewModelScope
            if (query.isEmpty()) {
                pokemonList.value = cachedPokemonList
                isSearching.value = false
                isSearchStarting = true
                return@launch
            }
            // Get results for names or ids in the list for the search
            val result = pokemonNameList.filter { it.first.contains(query.trim(), ignoreCase = true) || it.second.toString().contains(query.trim(), ignoreCase = true) }

            // Create a list of Pokedex entries that is empty
            val resultingPokemon = mutableListOf<PokedexListEntry>()
            // For each loaded pokemon pair (name, id) create a pokedex entry
            for (pokemon in result) {
                // Grab the id
                val num = pokemon.second
                // Create the image url using this link, replacing the number variable with the id
                val imgUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${num}.png"
                // Grab the name
                val name = pokemon.first
                // Create a pokedex entry with these variables
                val pokedexEntry = PokedexListEntry(pokemonName = name, imageUrl = imgUrl, number = num)
                // Add this entry into the resulting pokemon list
                resultingPokemon.add(pokedexEntry)
            }

            // Reset variables
            if (isSearchStarting) {
                cachedPokemonList = pokemonList.value
                isSearchStarting = false
            }

            // Return resulting pokemon
            pokemonList.value = resultingPokemon
            isSearching.value = true
        }
        Log.d("PARTIAL SEARCH", "DONE")
    }

    fun loadPokemonPaginated() {

        if (isLoading.value) return

        isLoading.value = true

        viewModelScope.launch {
            when(val result = repository.getPokemonList(PAGE_SIZE, curPage * PAGE_SIZE)) {
                is Resource.Success -> {
                    endReached.value = curPage * PAGE_SIZE >= result.data!!.count
                    val pokedexEntries = result.data.results.mapIndexed { index, entry ->
                        val number = if (entry.url.endsWith('/')) {
                            entry.url.dropLast(1).takeLastWhile { it.isDigit() }
                        } else {
                            entry.url.takeLastWhile { it.isDigit() }
                        }

                        val imgUrl = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${number}.png"
                        // entry.name.capitalize(Locale.ROOT) replace by replaceFirstChar
                        PokedexListEntry(entry.name.replaceFirstChar {
                            if (it.isLowerCase()) it.titlecase(
                                Locale.ROOT
                            ) else it.toString()
                        }, imageUrl = imgUrl, number = number.toInt())
                    }
                    curPage ++

                    loadError.value = ""
                    isLoading.value = false
                    pokemonList.value += pokedexEntries
                }
                is Resource.Error -> {
                    loadError.value = result.message!!
                    isLoading.value = false
                }
                else -> {
                    loadError.value = ""
                    isLoading.value = false
                }
            }
        }
    }

    fun calcDominantColor(drawable: Drawable, onFinish: (Color)->Unit) {
        // convert image from url into bitmap with config for library
        // True if the resulting bitmap should be mutable (i.e. its pixels can be modified)
        val bmp = (drawable as BitmapDrawable).bitmap.copy(Bitmap.Config.ARGB_8888, true)
        Palette.from(bmp).generate {palette ->
            palette?.dominantSwatch?.rgb?.let {colorValue ->
                onFinish(Color(colorValue))
            }
        }
    }
}