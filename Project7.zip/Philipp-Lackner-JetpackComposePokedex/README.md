# Pokedex by [Philipp Lackner](https://www.youtube.com/playlist?list=PLQkwcJG4YTCTimTCpEL5FZgaWdIZQuB7m)

This app was created following the playlist from Philipp Lackner using Jetpack Compose.
Each branch, from Part 1 to Part 9, consisted of code from the corresponding part of the playlist. 

# Branches
| Branch                                   | Purpose                                              | YouTube                                                |
|:-----------------------------------------|:-----------------------------------------------------|:-------------------------------------------------------|
| Part 1 : Navigation & Dagger Hilt        | Define Navigation                                    | [YT](https://youtu.be/v0of23TxIKc?si=CCdmiIWIIzHF-K9U) |
| Part 2 : Retrofit Setup                  | Prepare Retrofit                                     | [YT](https://youtu.be/aaChg9aJDW4?si=gwFxU6SUreetE3gY) |
| Part 3 : SearchBar and PokemonListScreen | Create SearchBar and define PokemonListScreen (Home) | [YT](https://youtu.be/O6k5Q2LoL0k?si=80httiN9gL3MZMEd) |
| Part 4 : Pokedex List Entry              | Define the Item Composable of PokemonList            | [YT](https://youtu.be/D06EV3PngJY?si=fdLHpsHihVw4Zncj) |
| Part 5 : PaginationPokemonList           | Define the pagination of Pokemon List                | [YT](https://youtu.be/jrIfGAk8PyQ?si=f7Xe0k02ZkrYxzqU) |
| Part 6 : Searching                       | Define behaviour when searching                      | [YT](https://youtu.be/X4Y63Cw9Gmw?si=In7DlR-7FRs9WIg8) |
| Part 7 : Detail Screen                   | Define the Detail Screen                             | [YT](https://youtu.be/FgJLP-VIiRA?si=0kJ1MaHVqaZ2TogN) |
| Part 8 : Detail Screen Content           | Define the content of Detail Screen                  | [YT](https://youtu.be/18N-5MJlPKY?si=19trUuCmehO-YIQO) |
| Part 9 : Detail Screen Base Stat         | Define the Stat composable in Detail Screen          | [YT](https://youtu.be/UR-lrDimmPI?si=QEsnek7TvgRxwzRo) |


# Versions
|                Version                | Updates |
|:-------------------------------------:|:--------|
|                v1.0.0                 |Complete app from the tutorial|


